//
//  StudentLoanExtensions.swift
//  Manjot-S-Saha_Comp2125-001_Mid-Term_Ex-01
//
//  Created by Manjot Singh Saha on 2020-06-23.
//  Copyright © 2020 Manjot Singh Saha. All rights reserved.
//

import Foundation

public class StudentLoanExtensions : StudentLoan{
    
    public init?(studentLoanNumber: Int, studentName: String, studentLoanAmount:Double) {
        super.init(
            studentLoanNumber: studentLoanNumber,
            studentName: studentName,
            studentLoanAmount: studentLoanAmount
        )
    }
    
    // Defining Description method
    public var description: String {
        return String(format:"%@: %@\n%@: %@\n%@: %@\n%@: %@\n%@: %@",
        "Student Name", studentName,
        "Student Loan Number", studentLoanNumber,
        "Yearly Interest Rate", yearlyInterestRate, "%",
        "Student Loan Amount", studentLoanAmount,
        "Duration", duration, "yrs"
        )
    } // end property
    
}

