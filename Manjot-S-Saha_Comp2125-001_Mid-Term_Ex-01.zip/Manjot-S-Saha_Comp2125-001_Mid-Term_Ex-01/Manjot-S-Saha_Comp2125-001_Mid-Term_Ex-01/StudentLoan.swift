//
//  StudentLoan.swift
//  Manjot-S-Saha_Comp2125-001_Mid-Term_Ex-01
//
//  Created by Manjot Singh Saha on 2020-06-23.
//  Copyright © 2020 Manjot Singh Saha. All rights reserved.
//

import Foundation

// Declaration of class
public class StudentLoan {
    
    
// Declaring variables
    public private(set) var studentLoanNumber:Int = 0;
    public private(set) var studentName:String = "";

    // Declaring didSet
    public var yearlyInterestRate:Double = 0.00 {
        didSet {
            if yearlyInterestRate <= 2.00 || yearlyInterestRate >= 5.00 {
                print ("Interest Rate is invalid, resetting to \(oldValue)")
            }
        }
    }
    
    public var studentLoanAmount:Double = 0.00 {
            didSet {
                if studentLoanAmount < 0.00 {
                    print ("Loan Amount is invalid, resetting to \(oldValue)")
                }
            }
    }
    
    public var duration:Int = 0 {
        didSet {
            if duration <= 3 || duration >= 5 {
                print ("Duration is invalid, resetting to \(oldValue)")
            }
        }
    }
    
    // defining initializer
    public init() {}

    // defining initializer with appropriate values
    public init (studentLoanNumber: Int, studentName: String, yearlyInterestRate: Double, studentLoanAmount:Double, duration: Int) {
        self.studentLoanNumber = studentLoanNumber
        self.studentName = studentName
        
        if yearlyInterestRate >= 2.00 && yearlyInterestRate <= 5.00 {
            self.yearlyInterestRate = yearlyInterestRate
        }
        
        if duration >= 3 && duration <= 5 {
            self.duration = duration
        }
        
        if studentLoanAmount > 0.00 {
            self.studentLoanAmount = studentLoanAmount
        }
    }
    
    public func taxExemption() {
        var tax = 0.01 * studentLoanAmount
    }
    
    // Defininfg Monthly payments method
    public func calculateMonthlyInstallments(installments : Double ) -> Double{
        var installments = ((studentLoanAmount - (studentLoanAmount * (0.01))) * Double(yearlyInterestRate)) / Double(duration  * 12)
        return installments
    }
}


